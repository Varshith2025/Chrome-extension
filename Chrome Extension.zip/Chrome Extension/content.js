let problemListKey = 'codechef_problems';
newBookmark = window.location.href;

window.addEventListener("load", () => {
	addBookmarkButton();
});

function addBookmarkButton() {
	const bookmarkBtn = document.createElement("img");
	bookmarkBtn.src = chrome.runtime.getURL("assets/bookmark.png");
	bookmarkBtn.className = "calas1";
	bookmarkBtn.title = "Click to bookmark current timestamp";
	bookmarkBtn.style.height = "30px";
	bookmarkBtn.style.width = "30px";
	azAskDoubt = document.getElementsByClassName("_navigation-button__box_1dtux_951 _problemPageNavigation__box_1dtux_997")[0];
	azAskDoubt.append(bookmarkBtn);
   	// console.log(azAskDoubt);
	bookmarkBtn.addEventListener("click", addNewBookmarkEventHandler);
}

const addNewBookmarkEventHandler = async () => {
	currentProblemBookmarks = await fetchBookmarks();
	// console.log(currentProblemBookmarks);'
	problemName =
		document.getElementsByClassName("_titleStatus__container_1dtux_838")[0].lastChild
			.textContent;
	console.log(problemName);
	const newBookmarkObj = {
		url: newBookmark,
		desc: problemName,
	};
	console.log(newBookmarkObj.url);
	let addNewToBookmark = true;
	for (let i = 0; i < currentProblemBookmarks.length; i++) {
		if (currentProblemBookmarks[i].url == newBookmark) {
			addNewToBookmark = false;
		}
	}
	if (addNewToBookmark) {
		chrome.storage.sync.set({
			[problemListKey]: JSON.stringify([
				...currentProblemBookmarks,
				newBookmarkObj,
			]),
		});
	}
};



const fetchBookmarks = () => {
	return new Promise((resolve) => {
		chrome.storage.sync.get([problemListKey], (obj) => {
			resolve(obj[problemListKey] ? JSON.parse(obj[problemListKey]) : []);
		});
	});
};
